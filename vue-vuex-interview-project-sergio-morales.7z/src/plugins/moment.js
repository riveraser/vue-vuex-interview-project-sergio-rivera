import Vue from "vue";
import moment from "moment";
Vue.use(moment);
